const updateUi = (userEntry, moodInfo) => {
  document.querySelector('.entry-info').innerHTML = userEntry;
  document.querySelector('.mood-info').innerHTML = moodInfo;
};

export { updateUi };
