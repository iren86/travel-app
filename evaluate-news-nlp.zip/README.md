# Sentiment Analysis Project

## Overview

This is an asynchronous web app that uses Web API and user data to dynamically update the UI. 

Based on provided input, appropriate information retrieved from the Aylien API and presented to the user.
Implemented user input validation with relevant error message.
Application adopted for mobile and desktop versions.
