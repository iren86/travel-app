import 'babel-polyfill';
import { JSDOM } from 'jsdom';

const dom = new JSDOM();
global.document = dom.window.document;
global.window = dom.window;

const initialTestCase = () => {
  document.body.innerHTML = `
   <input id="user_input"/>
    <button id="submit_button">Add todo</button>
    <div id="results" style="display: none;">
        <div id="mood">Your mood:
            <div class="mood-info"></div>
        </div>
        <div id="entry">Your entry:
            <div class="entry-info"></div>
        </div>
     </div>
  `;
};

test('Check user input result', () => {
  initialTestCase();
  const { updateUi } = require('../src/client/js/client.js');
  const userEntryValue = 'Sad mood!';
  const moodInfoValue = 'positive';

  updateUi(userEntryValue, moodInfoValue);
  const userEntry = document.querySelector('.entry-info');
  const moodInfo = document.querySelector('.mood-info');

  expect(userEntry.innerHTML).toEqual(userEntryValue);
  expect(moodInfo.innerHTML).toEqual(moodInfoValue);
});
